package FusionInventory::Agent::Version;

use strict;
use warnings;

our $VERSION = "2.5.2-1";
our $PROVIDER = "FusionInventory";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2019-12-17 15:09"
];

1;

