package FusionInventory::Agent::Task::Inventory::Version;

use strict;
use warnings;

use constant VERSION => "1.9";

1;
